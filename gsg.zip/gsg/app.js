//var mcqApp = angular.module('mcqApp',["ngRoute"]);
var mcqApp = angular.module('mcqApp',["ngRoute"]);
	// configure our routes
	mcqApp.config(function($routeProvider) {
		$routeProvider
                        .when('/', {
				templateUrl : siteUrl+'/mcq/templates/test.html',
				controller  : 'testController'
			})
			
			.when('/test', {
				templateUrl : siteUrl+'/mcq/templates/test.html',
				controller  : 'testController'
			})

			
			.when('/review', {
				templateUrl : siteUrl+'/mcq/templates/review.html',
				controller  : 'reviewController'
			})

			
			.when('/report', {
				templateUrl : siteUrl+'/mcq/templates/report.html',
				controller  : 'reportController'
			})
                        
                        .when('/userAttemptedQues', {
				templateUrl : siteUrl+'/mcq/templates/userquestionattemptdetails.html',
				controller  : 'userAttemptedQuesController'
			});
	});

//var mcqServices = angular.module('mcqServices', ['ngResource']).value('version', '0.1');


	
	
        
      
