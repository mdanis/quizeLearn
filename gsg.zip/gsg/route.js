var mcqApp = angular.module('mcqApp',["ngRoute"]);
       
	// configure our routes
	mcqApp.config(function($routeProvider) {
		$routeProvider
                        
			.when('/test/:serviceId/:rackId/:type/:level/:QAType', {
				templateUrl : mcqBaseUrl+'/gsg/templates/test.html',
				controller  : 'testController'
			})

			
			.when('/review', {
				templateUrl : mcqBaseUrl+'/gsg/templates/review.html',
				controller  : 'reviewController'
			})

			
			.when('/report', {
				templateUrl : mcqBaseUrl+'/gsg/templates/report.html',
				controller  : 'reportController'
			})
                        .when('/report/:reportId', {
				templateUrl : mcqBaseUrl+'/gsg/templates/report.html',
				controller  : 'reportController'
			})
                        
                        .when('/userAttemptedQues', {
				templateUrl : mcqBaseUrl+'/gsg/templates/userquestionattemptdetails.html',
				controller  : 'userAttemptedQuesController'
			});
	});

mcqApp.run(function($rootScope, $location,service,mcqConst,$http) {
 
  $rootScope.$on('$routeChangeSuccess', function($event,current) {
     service.showLoader();

    $http({
            method: "post",
            url: mcqConst.baseUrl+"/lms/json/displayloginstatus",
            headers: {
                'Content-Type': 'application/json'
            }
           }).success(function(data) {
                if(data.mode == 'website'){
                  mcqConst.dataUrl = 'lms';
                  mcqConst.siteMode = 'website';
              }
              else if(data.mode == 'lms'){
                   mcqConst.dataUrl = 'schoollms';
                   mcqConst.siteMode = 'schoollms';
               }
           
     var parameters = current.params; 
   
       var type =  current.originalPath.split("/")[1];
     switch(type){
         case "test" :
             if(parameters.QAType == 'chapter')
             var url =   mcqConst.baseUrl+"/"+ mcqConst.dataUrl+"/json/getquestions/"+parameters.serviceId+"/"+parameters.rackId+"/"+parameters.type+"/"+parameters.level;
             else          
             var url =   mcqConst.baseUrl+"/"+ mcqConst.dataUrl+"/json/getgsgquestions/"+parameters.serviceId+"/"+parameters.rackId+"/"+parameters.type+"/"+parameters.level;
            break;
         case "report" :  if(!parameters.reportId) {
             var data =   service.getReportData();
             setTimeout(function(){$rootScope.$broadcast('updateQuestionData', data);},2000);
               
         return;  
     }else{
             var url =   mcqConst.baseUrl+"/lms/mcq/gsg-report/"+parameters.reportId;
         }
                 // var url =   mcqConst.baseUrl+"/gsg/data/reportData.json";   
             break;    
     
     }
             var successCallback = function(data){
                      $rootScope.$broadcast('updateQuestionData', data);
                    
               };
               var errorCallback = function(){
                    console.log("Error in fetching json data. ");
               };
               var options = {
                   url:url,
                   successCallback:successCallback,
                   errorCallback:errorCallback
               };
          //  alert(options.url)
            service.getJSON(options);
      
     
     
  });
  })
});
	
	
        
      
