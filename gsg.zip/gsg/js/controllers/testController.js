mcqApp.controller('testController', function($scope,service,mcqConst,$window) {
    
 $scope.testData = null;
 $scope.baseUrl = mcqConst.baseUrl;
 $scope.currentQuesIndex = 0;
 $scope.navStatus = [];
 $scope.userResponse = {};
 $scope.remainingTime = "";
 $scope.showReviewBtn = false;
 $scope.timeTaken = 0;
 $scope.feedback = {} ;
  $scope.feedback.show = false;
  $scope.showOverlay =  false;
 
 
  $scope.$on('updateQuestionData',function(event,data){
      //console.log(JSON.stringify(data))
       $scope.testData = data;
            $scope.init(data);
            $scope.showQuestion($scope.currentQuesIndex);
            //$scope.$apply();
            setTimeout(function() {
                $scope.rendered();
            }, 100);
  })
  

$scope.init = function(data) {
       
 
          $scope.userResponse = {
                "title":  data.title,
                "setID":data.setID,
                "Services":  data.Services,
                "testType": data.testType,
                 "timeDuration": data.timeDuration,
                 "timeTaken": "",
                 "level":  data.level,
                 "userData" : []
         };
       /* if(localStorage.getItem("em_mcq_"+mcqConst.userId)){
            $scope.userResponse=JSON.parse(localStorage.getItem("em_mcq_"+mcqConst.userId));
        }
        
       /* if(localStorage.getItem("em_mcq_"+mcqConst.userId)){
            $scope.userResponse = JSON.parse(localStorage.getItem("em_mcq_"+mcqConst.userId));
        }else{
           localStorage.setItem("em_mcq_"+mcqConst.userId, JSON.stringify($scope.userResponse));
         
        }*/
        localStorage.setItem("em_mcq_"+mcqConst.userId, JSON.stringify($scope.userResponse));
        if(data.timeDuration){
          $scope.remainingTime = (data.timeDuration).toString();
        }
        angular.forEach(data.data, function(item, index) {
            $scope.navStatus[index] = {
                "skipped": false,
                "attempted": false,
                "active": false,
                "disabled": true
            };
            //alert(item.questiondata.language);
            if(item.questiondata.language=='Mangal' || item.questiondata.language=='Kruti Dev 010')
            $scope.language = 'hindi';
        else
            $scope.language = '';
            
            
             $scope.userResponse.userData.push({  
                 "questionid": item.questiondata.questionid,
                 "attempts":0,
                 "answerIds": [],
                 "status":"",
                 "dataItem":item
             });
        });

    }
    
    
    $scope.rendered = function() {
        service.hideLoader();
        $scope.navStatus[$scope.currentQuesIndex].disabled = false;
        $scope.navStatus[$scope.currentQuesIndex].active = true;

       // $scope.Timer($scope.remainingTime);
       
    }

    $scope.showQuestion = function(index, e) {
        if (index != 0 && index == $scope.currentQuesIndex) {
            return;
        }
        $scope.feedback.show = false;
        $scope.showOverlay = false;
        var enabled = false;
        if (typeof e == "object") {
            if (e.target.classList.contains("disabled")) {
                return;
            }
            enabled = true;

        } else {
            enabled = true;
        }
        if (!enabled) {
            return;
        }
        $scope.prevBtnDisabled = (index == 0) ? true : false;
        $scope.nextBtnDisabled = (index == $scope.testData.data.length - 1) ? true : false;
     // alert(index +'=='+ $scope.testData.data.length)
     if(index == $scope.testData.data.length){
         
          $scope.showResult();
     }

        if (index >= 0 && index < $scope.testData.data.length) {

           // console.log("showQuestion :: " + index);

            angular.forEach($scope.navStatus, function(nav) {
                nav.active = false
            });

            $scope.navStatus[index].disabled = false;
            $scope.navStatus[index].active = true;
           
           
            $scope.SaveResponse($scope.currentQuesIndex);
            $scope.handleNavItem($scope.currentQuesIndex);
            $scope.currentQues = $scope.testData.data[index];
            $scope.currentQuesIndex = index;

            if ($scope.userResponse.userData[index].answerIds.length != 0) {
                var answerIds = $scope.userResponse.userData[index].answerIds;
                setTimeout(function() {
                    angular.forEach(answerIds, function(id) {
                        $('#option_' + id).attr("checked", "checked");
                    });
                }, 500);

            }

        }
//        if($scope.testData.data[index].questiondata.questionlanguage){
//            if($scope.testData.data[index].questiondata.questionlanguage.toLowerCase())
//            {
//                
//                setTimeout(function(){
//                    //hindi font use
//                    $('.mcqHeading .col6 p').addClass('hindi');
//                    $('.mcqContent *:not(:has(*))').addClass('hindi');
//
//                },1000);
//            }
//        }
    }
    $scope.hideFeedback = function(){
        $scope.showOverlay = false; 
        $scope.feedback.show = false;
    }
    $scope.selectOption = function(e){
      
        var node = e.currentTarget;
        var elem;
       
       if(node.tagName != "LI"){
           node = node.parentNode;
          
       }
 
       if(angular.element(node).hasClass("incorrect")){
           $scope.feedback.image = "popup_alert.png";
           $scope.feedback.show = true;
           $scope.showOverlay = true;
           return;
       }
       $scope.userResponse.userData[$scope.currentQuesIndex].attempts += 1;
       var feedback = {};
       var selectedAns =angular.element(node).find(".qt").data("id");
       var correctAns = $scope.currentQues.rightanswerdata.rightanswer[0].answerid;
       $scope.userResponse.userData[$scope.currentQuesIndex].answer =  $scope.currentQues.rightanswerdata.rightanswer[0].answer;
       var attempts = $scope.userResponse.userData[$scope.currentQuesIndex].attempts;
      
       var ansArray = []
       ansArray.push(selectedAns);
        $scope.userResponse.userData[$scope.currentQuesIndex].answerIds = ansArray; 
        var correctAnsNode = angular.element(("[data-id="+correctAns+"]")).get(0).parentNode
        var order = correctAnsNode.id.split("optLi_")[1]
        $scope.userResponse.userData[$scope.currentQuesIndex].ansIndex = String.fromCharCode(97+parseInt(order))
      
      feedback =  $scope.userResponse.userData[$scope.currentQuesIndex];
     
       if(selectedAns == correctAns){
          
           $scope.userResponse.userData[$scope.currentQuesIndex].status = true;
           angular.element("#nav_"+$scope.currentQuesIndex).addClass("correct");
           if(attempts == 1)
            {
                feedback.points = 10;
                feedback.image = "popupR.png";
               
            }
            else
            { feedback.points = 5;
                 feedback.image = "popupR1.png";
               
            }
       }else{
            
            $scope.userResponse.userData[$scope.currentQuesIndex].status = false;
           if(attempts == 1)
            {
                feedback.image = "popupW1.png";
                angular.element(node).addClass("incorrect");
            }
            else
            {   angular.element("#nav_"+$scope.currentQuesIndex).addClass("incorrect");
                feedback.image = "popupW.png";
                
            }
       }
      
   $scope.feedback = feedback;
   $scope.feedback.show = true;
   $scope.showOverlay = true;
    
    
    
   }
    $scope.SaveResponse = function(index) {
        

        var selectedAns = $('input[name=options]:checked');
        if (selectedAns.length != 0) {
       
        var ansArray = [];
         angular.forEach(selectedAns, function(elem) {
            var id = parseInt($(elem).attr("id").split("option_")[1]);        
            this.push(id);         
        }, ansArray);
      
        $scope.userResponse.userData[index].answerIds = ansArray;           
        $scope.showReviewBtn = true;
            
        }
        localStorage.setItem("em_mcq_"+mcqConst.userId, JSON.stringify($scope.userResponse));
        
    }

    $scope.showPrevQ = function() {
        $scope.showQuestion($scope.currentQuesIndex - 1, true);

    }
    $scope.showNextQ = function() {

        $scope.handleNavItem($scope.currentQuesIndex);
        $scope.showQuestion($scope.currentQuesIndex + 1, true);

    }
    $scope.handleNavItem = function(index) {

         if ($scope.userResponse.userData[index].answerIds.length != 0){

            $scope.navStatus[index].skipped = false;
            $scope.navStatus[index].attempted = true;

        } else {
            $scope.navStatus[index].skipped = true;
            $scope.navStatus[index].attempted = false;
        }
        $scope.navStatus[index].disabled = false;



    }
  
    $scope.Timer = function(minutes) {
        var remainingTime = parseInt(minutes) * 60 * 1000;
        var timerId = setInterval(function() {
            remainingTime -= 1000;
            $scope.timeTaken += 1000;
            var min = Math.floor(remainingTime / (60 * 1000));
            var sec = Math.floor((remainingTime - (min * 60 * 1000)) / 1000);

            if (remainingTime == 0) {
                alert("Time Up");
                clearInterval(timerId);
                $scope.showResult();
            } else {
                $scope.remainingTime = min + ":" + sec;
                 $scope.$apply();
            }

        }, 1000)

    }
    
     $scope.showReview = function() {
       
        $scope.SaveResponse($scope.currentQuesIndex);
        var reviewData = [];
   
      
            angular.forEach($scope.userResponse.userData, function(item,index) {
                var ques = $scope.testData.data[index].questiondata.question;
                
                if(!(item.answerIds.length == 0 && $scope.currentQuesIndex == index)){
                
                if(!$scope.navStatus[index].disabled){
                 
                
                if(item.answerIds.length == 0 ){
                    var ans = "skipped"; 
                }
                else{
                
                var ans = "";
                angular.forEach(item.answerIds, function(id) {
                     ans  += _.findWhere($scope.testData.data[index].optiondata.options, {optionid: parseInt(id)}).optiontext + " <br />";
                    
                    
                });
                }
                
              
                  reviewData.push({
                     "ques" : ques,
                     "ans" :ans
                  });
                  
                }
                }
      
            },reviewData);
            
         service.setReviewData(reviewData);
         
         $window.open(mcqConst.appUrl+"#/review",'_blank',"height=600,width=1000")
     // location.hash  = "review";

    } 
    
     $scope.showResult = function() {
       
        $scope.SaveResponse($scope.currentQuesIndex);
                
          var min = Math.floor($scope.timeTaken / (60 * 1000));
            var sec = Math.floor(($scope.timeTaken - (min * 60 * 1000)) / 1000);
            
            
        $scope.userResponse.timeTaken = min + ":"+ sec;
        localStorage.setItem("em_mcq_"+mcqConst.userId, JSON.stringify($scope.userResponse));
        
    var successCallback = function(data){
            service.setReportData($scope.userResponse); 
            location.hash  = "report";
            localStorage.removeItem("em_mcq_"+mcqConst.userId);
           
       };
       
       var errorCallback = function(){
             alert("Error in saving and fetching data");
           
       };
       
         console.log("userResponse data :: ", $scope.userResponse)
       var options = {
           //url: mcqConst.baseUrl+"/mcq/data/reportData.json",
           url: mcqConst.baseUrl+"/lms/mcq/end-gsg-test",
           data: $scope.userResponse,
           successCallback:successCallback,
           errorCallback:errorCallback
       };
     
       service.getJSON(options)
        
        

    }
        
});

