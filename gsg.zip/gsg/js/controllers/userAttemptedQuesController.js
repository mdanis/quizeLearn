  mcqApp.controller('userAttemptedQuesController', function($scope,$window,service,mcqConst) {
  $scope.baseUrl = mcqConst.baseUrl;
     	
    $scope.$on('$viewContentLoaded',function(event){
       
        console.log(JSON.stringify(service.getAttemptDetails()))
          $scope.data =  service.getAttemptDetails();       
          service.hideLoader();
    }); 
      
$scope.getYourAns = function(){
    var ques =$scope.data.userData;
    var ansIds = ques.answerIds;
     var ansStr = "<b>Your Answer : ";
    if(ansIds.length == 0) {
        ansStr += "skipped";
    }
   else{
     angular.forEach(ansIds, function(id,index) {
      // ansStr += (index+1) + ". ";
       //ansStr  += _.findWhere($scope.data.questionDetails.dataItem.optiondata.options, {optionid:id.toString()}).optiontext + " <br />";
                 angular.forEach($scope.data.questionDetails.dataItem.optiondata.options,function(val,index){
                     if(val.optionid == id){
                          ansStr += (index+1) + ". ";
                          ansStr+=val.optiontext;
                     }
                         
                 })   
       
        },ansStr);
        
      }
        return ansStr;
        
}

$scope.getCorrectAns = function(){
 var ques = $scope.data.userData;
   var ansStr  = "<b>Right Answer :  "+ques.answer;
      
        return ansStr;
}

$scope.closeWindow = function(){
    $window.close();
}
  
  
  
	});
