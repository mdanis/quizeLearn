
mcqApp.controller('reportController', function($scope,$window,service,mcqConst) {
	$scope.baseUrl = mcqConst.baseUrl;
     
 $scope.$on('updateQuestionData',function(event,data){
    
    
       $scope.reportData =  data;
    
          service.hideLoader();
       
       var totalQuestionCount =    data.userData.length;
       var totalCorrectCount =    _.where(data.userData,{"status":true}).length;
       var percentage = (totalCorrectCount*100)/totalQuestionCount;
        var correctCount1 =    _.where(data.userData,{"attempts":1}).length;
         var correctCount2 =    _.where(data.userData,{"status":true,"attempts":2}).length;
          var totalWrongCount =    _.where(data.userData,{"status":false}).length;
           var wrongCount1 =    _.where(data.userData,{"attempts":2}).length;
           var wrongCount2 =    _.where(data.userData,{"status":false}).length;
           
           $scope.testData = {
               "totalQuestionCount":totalQuestionCount,
              "totalCorrectCount":totalCorrectCount,
              "percentage":percentage,
               "correctCount1" :correctCount1,
               "correctCount2":correctCount2,
               "totalWrongCount":totalWrongCount,
               "wrongCount1":wrongCount1,
               "wrongCount2":wrongCount2
               
           }
        
          $scope.createReportChart();
 })
      $scope.$on('$viewContentLoaded',function(event){
          var isChrome = /Chrome/.test(navigator.userAgent) && /Google Inc/.test(navigator.vendor);
          var isSafari = /Safari/.test(navigator.userAgent) && /Apple Computer/.test(navigator.vendor);

        if (isChrome)
            checkForGsG = true;
        else if (isSafari)
            checkForGsG = true;
        else
            checkForGsG = false;

         
     var data = service.getReportData();
      $scope.reportData =  data;
     
          service.hideLoader();
       
       var totalQuestionCount =    data.userData.length;
       var totalCorrectCount =    _.where(data.userData,{"status":true}).length;
       var percentage = ((totalCorrectCount*100)/totalQuestionCount).toFixed(2);
        var correctCount1 =    _.where(data.userData,{"attempts":1}).length;
         var correctCount2 =    _.where(data.userData,{"status":true,"attempts":2}).length;
          var totalWrongCount =    _.where(data.userData,{"status":false}).length;
           var wrongCount1 =    _.where(data.userData,{"attempts":2}).length;
           var wrongCount2 =    _.where(data.userData,{"status":false}).length;
           
           $scope.testData = {
               "totalQuestionCount":totalQuestionCount,
              "totalCorrectCount":totalCorrectCount,
              "percentage":percentage,
               "correctCount1" :correctCount1,
               "correctCount2":correctCount2,
               "totalWrongCount":totalWrongCount,
               "wrongCount1":wrongCount1,
               "wrongCount2":wrongCount2
               
           }
       
          //$scope.createReportChart();
      });       
      
          $scope.createReportChart = function() {
          var pieData = [
            {
                value:  $scope.testData.totalCorrectCount,
                color:"green"
                
            },
            {
                value : $scope.testData.totalWrongCount,
                color : "#D01F3C"
                
            }
        
        ];
               
              
         
    var options={
        segmentShowStroke : true,
        animation : true,
        scaleShowLabels : true
        };
      var myPie = new Chart(document.getElementsByClassName("report-canvas")[0].getContext("2d")).Pie(pieData,options);


    };
   $scope.getMessage = function(percentScored){
       var data = $scope.reportData;
       var msg = "";
             
                if (percentScored >= 60) {
                    if (data.level == 3 || data.testType == 'practice' || data.testType == 'multiple') {
                        msg = 'Your Performance is excellent.';
                    } else {
                        msg = 'Your Performance is excellent.';
                    }             
                } else if (percentScored <= 40) {
                        msg = 'Your performance needs improvement. Please retake the test';
                    } else if (percentScored >= 41 && percentScored <= 60) {
                        msg = 'Your performance is average. Please retake the test';
                    } else {
                        msg = 'Your performance is good. However, please retake the test to improve your scores';
                    }
           return msg;       
                
   }
      $scope.showAttemptedQuestion = function(index){

          var data = {
           "title": $scope.reportData.title,
           "testType": $scope.reportData.testType,
           "level":$scope.reportData.level,
           "userData" : $scope.reportData.userData[index],
           "questionDetails" : $scope.reportData.userData[index],
          };
         
          // console.log(JSON.stringify(data))
     
        service.setAttemptDetails(data)
       $window.open(mcqConst.appUrl+"#/userAttemptedQues",'_blank',"height=600,width=1000")
    };
    $scope.getUserAnswer = function(index){
       var orderIds =   $scope.reportData.testdata[index].resultdata.orderIds;
       if(orderIds.length == 0){
           return "N/A";
       }
       var str = "";
       angular.forEach(orderIds,function(id,indx){
           str += String.fromCharCode(96+parseInt(id));
           if(indx< (orderIds.length - 1)){
               str += ",";
           }
       });
       
       return str;
    };
                
     $scope.closeResult = function() {        
       $window.close();
        
    }
    
      $(window).bind("beforeunload",function(e) {
          $scope.refeshParent();
        //  return ""
        
       });
       
     $scope.refeshParent =  function() {
            if (window.opener != null && !window.opener.closed) {
                if(window.opener.location.href.indexOf("testlevel") >= 0){
                window.opener.location.reload();
                }
            }
        }
        
        
        
	});
