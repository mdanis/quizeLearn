mcqApp.service('service', function(mcqConst,$http) {
    

  var reportData = [];
  
 var setQuestionData = function(data) {
      //reviewData = data;
      localStorage.setItem("em_mcq_questionData_"+mcqConst.userId, JSON.stringify(data));
      
  }
  var getQuestionData = function() {
      return JSON.parse(localStorage.getItem("em_mcq_questionData_"+mcqConst.userId));
  }
  var setReviewData = function(data) {
      //reviewData = data;
      localStorage.setItem("em_mcq_reviewData_"+mcqConst.userId, JSON.stringify(data));
  }
  var getReviewData = function() {
    // return reviewData;
    return JSON.parse(localStorage.getItem("em_mcq_reviewData_"+mcqConst.userId));
  }
  var setReportData = function(data) {
   //  reportData = data;
     localStorage.setItem("em_mcq_reportData_"+mcqConst.userId, JSON.stringify(data));
  }
  var getReportData = function() {
    //  return reportData;
   return JSON.parse(localStorage.getItem("em_mcq_reportData_"+mcqConst.userId));
  }
   var setAttemptDetails = function(data) {
    localStorage.setItem("em_mcq_attemptData_"+mcqConst.userId, JSON.stringify(data));
  }
   var getAttemptDetails = function() {
   return JSON.parse(localStorage.getItem("em_mcq_attemptData_"+mcqConst.userId));
  }
  
    var removeInlineStyle = function(data){
      if(typeof data == "string") {
          return data.replace(/style=".*?"/i, '');
      }else{
         var dataStr = JSON.stringify(data);
         dataStr = dataStr.replace(/style=".*?"/i, '');
         return JSON.parse(dataStr);
      }
  }
  
   var getJSON = function(options){
     
     if(mcqConst.touchDevice){
         
       var data = getJSONData(options);
       if(data){
         options.successCallback(data);
       }else{
           options.errorCallback();
       }
     
 }else{
    
        $http({
        method: "post",
        url: options.url,
        data:options.data,
        headers: {
            'Content-Type': 'application/json'
        }
        }).success(function(data) {
            removeInlineStyle(data)
          options.successCallback(data);


        }).error(function() {
          options.errorCallback();
        });
         
     }
 }

    var showLoader = function(){
       $(".preloader").show();	
    }
     var hideLoader = function(){
     $(".preloader").hide();
   }
  return {
    setReviewData: setReviewData,
    getReviewData: getReviewData,
    setReportData:setReportData,
    getReportData:getReportData,
    setAttemptDetails:setAttemptDetails,
    getAttemptDetails:getAttemptDetails,
    setQuestionData:setQuestionData,
    getQuestionData:getQuestionData,
    getJSON:getJSON,
    removeInlineStyle:removeInlineStyle,
    showLoader:showLoader,
    hideLoader:hideLoader
  };



});
