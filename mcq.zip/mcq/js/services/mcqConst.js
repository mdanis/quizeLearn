mcqApp.service('mcqConst', function() {
  
  return {
    userId : "",
    baseUrl: ""
    
  };



});
