mcqApp.controller('reportController', function($scope,$window,service,mcqConst) {
	$scope.baseUrl = mcqConst.baseUrl;

 $scope.$on('updateQuestionData',function(event,data){
     // $scope.reportData =  service.getReportData();
       $scope.reportData =  data;
          service.hideLoader();
           var timeTaken = $scope.reportData.testResultData.timeTaken;
           var timeArray  = timeTaken.split(":");
           $scope.timeTaken = timeArray[0] + " min "+ timeArray[1] + " sec"; 
          $scope.createReportChart();
 })
 

      $scope.$on('$viewContentLoaded',function(event){
          $scope.reportData =  service.getReportData();
          service.hideLoader();
           var timeTaken = $scope.reportData.testResultData.timeTaken;
           var timeArray  = timeTaken.split(":");
           $scope.timeTaken = timeArray[0] + " min "+ timeArray[1] + " sec"; 
          $scope.createReportChart();
      });            
      
          $scope.createReportChart = function() {
          var pieData = [
            {
                value: $scope.reportData.testResultData.correct,
                color:"#2C6085"
                
            },
            {
                value :$scope.reportData.testResultData.incorrect,
                color : "#D01F3C"
                
            },
            {
                value : $scope.reportData.testResultData.skipped,
                color : "#FB9EA6"
                
            },
            {
                value : 0.0001,
                color : "#ffffff"
                
            }
        
        ];
               
              
         
    var options={
        segmentShowStroke : true,
        animation : true,
        scaleShowLabels : true
        };
      var myPie = new Chart(document.getElementsByClassName("report-canvas")[0].getContext("2d")).Pie(pieData,options);


    };
   $scope.getMessage = function(){
       var data = $scope.reportData;
       var msg = "";
          var percentScored = parseInt(((parseInt(data.testResultData.correct) / parseInt(data.totalQuestions)) *100).toFixed(0));
                 
                if (percentScored >= 60) {
                    if (data.level == 3 || data.testType == 'practice' || data.testType == 'multiple') {
                        msg = 'Your Performance is excellent.';
                    } else {
                        msg = 'Your Performance is excellent. Please continue to the next level.';
                    }             
                } else if (percentScored <= 40) {
                        msg = 'Your performance needs improvement. Please retake the test';
                    } else if (percentScored >= 41 && percentScored <= 60) {
                        msg = 'Your performance is average. Please retake the test';
                    } else {
                        msg = 'Your performance is good. However, please retake the test to improve your scores';
                    }
           return msg;       
                
   }
      $scope.showAttemptedQuestion = function(index){
          var data = {
           "title": $scope.reportData.title,
           "testType": $scope.reportData.testType,
           "level":$scope.reportData.level,
           "questionDetails" : $scope.reportData.testdata[index]
          };
          
     
        service.setAttemptDetails(data)
       $window.open(mcqConst.appUrl+"#/userAttemptedQues",'_blank',"height=600,width=1000,scrollbars=yes")
    };
    $scope.getUserAnswer = function(index){
       var orderIds =   $scope.reportData.testdata[index].resultdata.orderIds;
       if(orderIds.length == 0){
           return "N/A";
       }
       var str = "";
       angular.forEach(orderIds,function(id,indx){
           str += String.fromCharCode(96+parseInt(id));
           if(indx< (orderIds.length - 1)){
               str += ",";
           }
       });
       
       return str;
    };
                
     $scope.closeResult = function() {  
       $scope.refeshParent();
       $window.close();
        
    }
    
      $(window).bind("beforeunload",function(e) {
          $scope.refeshParent();
        //  return ""
        
       });
       
     $scope.refeshParent =  function() {
            if (window.opener != null && !window.opener.closed) {
                if(window.opener.location.href.indexOf("testlevel") >= 0){
                window.opener.location.reload();
                 $window.close();
                }
                else if(window.opener.location.href.indexOf("practicepaper") >= 0){
                     window.opener.location.reload();
                     $window.close();
                 }
            }
        }
        $scope.addMcqClass = function(len){
            if(len>10)
                return 'queslen20';
            else
                return 'queslen10';
        }
        
        
	});
