mcqApp.controller('reviewController', function($scope,$window,service,mcqConst) {
       $scope.baseUrl = mcqConst.baseUrl;
     
      $scope.$on('$viewContentLoaded',function(event){
            $scope.reviewData =  service.getReviewData();
            service.hideLoader();
      });
      $scope.closeReview = function() {
       $window.close();

    }
	});
