mcqApp.controller('mainController', function($scope,mcqConst,$rootScope,$route,service) {
        mcqConst.userId = "ankita";
        mcqConst.baseUrl = mcqBaseUrl;
	mcqConst.appUrl = location.href.split("#")[0];
        service.showLoader();
        $("body").css("overflow-x","hidden");
      /*  $rootScope.$on('$routeChangeSuccess', function($route){
    alert("$routeChangeSuccess")
    
    
     });*/
	});
