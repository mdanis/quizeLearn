var mcqApp = angular.module('mcqApp',["ngRoute"]);
       
	// configure our routes
	mcqApp.config(function($routeProvider) {
		$routeProvider
                        
			.when('/test/:serviceId/:rackId/:type/:level', {
				templateUrl : mcqBaseUrl+'/mcq/templates/test.html',
				controller  : 'testController'
			})

			
			.when('/review', {
				templateUrl : mcqBaseUrl+'/mcq/templates/review.html',
				controller  : 'reviewController'
			})

			
			.when('/report', {
				templateUrl : mcqBaseUrl+'/mcq/templates/report.html',
				controller  : 'reportController'
			})
                        .when('/report/:reportId', {
				templateUrl : mcqBaseUrl+'/mcq/templates/report.html',
				controller  : 'reportController'
			})
                        
                        .when('/userAttemptedQues', {
				templateUrl : mcqBaseUrl+'/mcq/templates/userquestionattemptdetails.html',
				controller  : 'userAttemptedQuesController'
			});
	});

mcqApp.run(function($rootScope, $location,service,mcqConst,$http) {
 
  $rootScope.$on('$routeChangeSuccess', function($event,current) {
     service.showLoader();
      $http({
            method: "post",
            url: mcqConst.baseUrl+"/lms/json/displayloginstatus",
            headers: {
                'Content-Type': 'application/json'
            }
           }).success(function(data) {
                if(data.mode == 'website'){
                  mcqConst.dataUrl = 'lms';
                  mcqConst.siteMode = 'website';
              }
              else if(data.mode == 'lms'){
                   mcqConst.dataUrl = 'schoollms';
                   mcqConst.siteMode = 'schoollms';
               }
     var parameters = current.params; 
       var type =  current.originalPath.split("/")[1];
     switch(type){
         case "test" :  var url =   mcqConst.baseUrl+"/"+mcqConst.dataUrl+"/json/getquestions/"+parameters.serviceId+"/"+parameters.rackId+"/"+parameters.type+"/"+parameters.level;
             break;
         case "report" :  if(!parameters.reportId) {
             var data =   service.getReportData();
                  $rootScope.$broadcast('updateQuestionData', data);
            
              
         return;  
     }else{
             var url =   mcqConst.baseUrl+"/lms/mcq/report/"+parameters.reportId;
         }
             break;    
     
     }
             var successCallback = function(data){
                      $rootScope.$broadcast('updateQuestionData', data);
                    
               };
               var errorCallback = function(){
                    console.log("Error in fetching json data. ");
               };
               var options = {
                   url:url,
                   successCallback:successCallback,
                   errorCallback:errorCallback
               };
            service.getJSON(options);
      
     
     
  });

  });
});
	
	
        
      
