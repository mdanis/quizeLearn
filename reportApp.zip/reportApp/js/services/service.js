reportApp.service('service', function($http,appConst,$window,$rootScope) {

 
  var getServiceData = function(params) {

        $http({
            method: "post",
            url: params.url,
            headers: {
                'Content-Type': 'application/json'
            }
        }).success(function(data) {
           params.successCallback(data);
       }).error(function(e){
           params.errorCallback(e)
       })
  }
  var getBreadscumData = function(URL){
           $http({
           method: "post",
           url: URL,
           headers: { 'Content-Type': 'application/json' }
        }).success(function(data) {
             $rootScope.$broadcast('updateBreadscum',data);
       });
  }
  var updatReportByBreadscum = function(data){
      
  }
   var showLoader = function(id){
       $("#preloader_"+id).show();	
    }
     var hideLoader = function(id){
     $("#preloader_"+id).hide();
   }

 
  return {
    getServiceData: getServiceData,
    showLoader:showLoader,
    hideLoader:hideLoader,
    getBreadscumData:getBreadscumData
    
  };



});


