reportApp.service('appConst', function() {
  
  return {
    userId : "",
    siteUrl: "",
  
    
  };



});
