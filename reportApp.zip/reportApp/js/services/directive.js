
/* ***********  slideDown and slideUp for classes and other show hide functionality *********** */
reportApp.directive('slideToggle', function() {  
  return {
    restrict: 'A',      
    scope:{},
    controller: function ($scope) {},
    link: function(scope, element, attr) {
      element.bind('click', function() {
            $('#subsubject').hide();
            $('#subsubjectchapters').hide();
            $('#thirdLevelChapter').hide();
          if(element.attr('class').indexOf('askQue') >= 0)   
            $('.add-quesBg').hide();
         else if(element.attr('class').indexOf('addNotes')  >= 0)
             $('.add-notesBg').hide();
        var $slideBox = angular.element(attr.slideToggle);
        var slideDuration = parseInt(attr.slideToggleDuration, 10) || 200;
        $slideBox.stop().slideToggle(slideDuration);
      });
    }
  };  
});

/* *********************  click directive used for breadscum ********************** */
reportApp.directive("click", function (service,appConst) {
    
  return {
       scope: { breadscumList: '=click'},
       link :function (scope, element, attrs) {
       element.bind("click", function () {
         // location.hash = "/coverage/"+scope.breadscumList.rack_id; 
         if(element.attr('class').indexOf('last')<0)
          location.hash = "/coverage/"+appConst.userId+"/"+scope.breadscumList.rack_id; 
    })
  }
  }
})