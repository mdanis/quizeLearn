
reportApp.controller('coverageController', function($scope, $http, service,appConst,$rootScope,$window) {
    
    $scope.mode=mode
    $scope.showMode = false;
    $scope.siteUrl = appConst.siteUrl;
     $scope.reportType = "MCQ";
     service.hideLoader('default');
      service.showLoader("coverage");
       service.showLoader("schedule");
        service.showLoader("test");
      //$scope.showCoverage = false;
     // $scope.showTestCoverage = false;
       $scope.$on("updateCoverData", function(event, data) {
            $scope.showMode = ($scope.mode == 'lms')?false:true; 
            $scope.coverage = data.coverage;
            $scope.userType = data.userType;
            $scope.testPackage = data.testPackage; //true or false value
            //$scope.showCoverage = true;
            if(data.testPackage){
                $scope.testcoverage = data.testcoverage;
                //$scope.showTestCoverage = false;
            }
            setTimeout(function() { 
              $scope.onCoverageReady();
              
              if(data.testPackage){
                $('.activeCurrentTab').removeClass('active');
                $('.activeCurrentTab').eq(0).addClass('active');
                $scope.onTestCoverageReady();
            }
         }, 100);
      })
      
       $scope.$on("updateTestData", function(event, data) {
            if(data){
           $scope.pData = data;
           $scope.showTestTypeReport("mcq");
            }
           service.hideLoader("test");
      })
      
      $scope.$on("updateScheduleData", function(event, data) {
     

          if(data){
           $scope.schedule = data;
           $scope.TPT_Count = _.where($scope.schedule.today, {status: "incomplete"}).length;
          }
          service.hideLoader("schedule");
      })
     
  
    
    $scope.showDetail = function(id){
      $window.open($scope.siteUrl+"/report/index/test-history/"+appConst.userId+"/"+id,"_blank;")   
    }
     $("#selectmcqMct").selectbox({
            onChange:function(val,inst){
                $('#sbSelector_'+inst.uid).text(val);
                var type = val.toLowerCase();
                var type1 = '';
                if(type == "mcq"){
                    type1 = 'single';
                }else{
                     type1 = 'multiple';
                }
                $scope.performance =   $scope.pData[type1];
                $("#performance-carousel").data('owlCarousel').destroy();
                setTimeout(function() { 
                  $("#performance-carousel").owlCarousel({
                            autoPlay: false, //Set AutoPlay to 3 seconds
                            navigation : true,
                            pagination : false, 
                            items : 3,
                            itemsDesktop : [1199,3],
                            itemsDesktopSmall : [979,3]
                            });
             }, 100);
            }
        });
    $scope.showTestTypeReport = function(type){
         $scope.performance =   $scope.pData['single'];
         setTimeout(function(){
            $("#performance-carousel").owlCarousel({
                    autoPlay: false, //Set AutoPlay to 3 seconds
                    navigation : true,
                    pagination : false, 
                    items : 3,
                    itemsDesktop : [1199,3],
                    itemsDesktopSmall : [979,3]
                    }); 
              },100)
         
    }
     $scope.showSchedule = function(){
        // $("#reminder_pop1").attr("src",$scope.siteUrl+"/scheduler-report/"+appConst.userId);
        $("#reminder_pop1").load($scope.siteUrl+"/scheduler-report/"+appConst.userId);
        //$("#iframe_wrapper").show();
        $("#overlay").show();
     } 
     
     
     $scope.mcqTestEligiblity = function(userType){
         if(userType == 'junior'){
            alert("This section is not active for you.")
         }
     }
     $scope.onCoverageReady = function(){
         $scope.createPieChart();
          $("#coveragereport").owlCarousel({
          autoPlay: false, //Set AutoPlay to 3 seconds
          navigation : true,
          pagination : false, 
          items : 5,
          itemsDesktop : [1199,5],
          itemsDesktopSmall : [979,4]
          });
      service.hideLoader("coverage");
     } 
     
    $scope.onTestCoverageReady = function(){
       
         $scope.createTestPieChart();
          $("#testcoveragereport").owlCarousel({
            autoPlay: false, //Set AutoPlay to 3 seconds
            navigation : true,
            pagination : false, 
            items : 5,
            itemsDesktop : [1199,5],
            itemsDesktopSmall : [979,4]
            });
      $('#coveragereport').hide();
      $('#testcoveragereport').show();
      service.hideLoader("coverage");
     } 
     
     
      $scope.createPieChart = function(){
         angular.forEach( $scope.coverage, function(data,index) {
           $('#spn'+index).easyPieChart({barColor:'#67bde9'});
        });
      }
      
      $scope.createTestPieChart = function(){
         angular.forEach( $scope.testcoverage, function(data,index) {
           $('#spn2'+index).easyPieChart({barColor:'#67bde9'});
                  
        });
      }
      $scope.showSubjectReport = function(subjectId){
          appConst.subjectId = subjectId;
          location.hash = "/subjectreport/"+appConst.userId+"/"+appConst.classId+'/'+subjectId;
         
      }
      
       //cloned from above for test package
      $scope.showSubjectTestReport = function(subjectId){
          appConst.subjectId = subjectId;
          location.hash = "#/subjecttestreport/"+appConst.userId+"/"+appConst.classId+'/'+subjectId;
         
      }
      
      $scope.closeReminder = function(){
          // $("#reminder_pop1").hide();
            $("#iframe_wrapper").hide();
            $("#overlay").hide();
             service.showLoader("schedule");
            
          $http({
                method: "post",
                url:  appConst.siteUrl+"/report/json/get-schedule/"+appConst.userId,
                headers: {
                    'Content-Type': 'application/json'
                }
            }).success(function(data) {
               $rootScope.$broadcast('updateScheduleData', data);
            });

                            
      }
      $scope.getClass = function(percent){
          if(percent >= 0 && percent <= 33){
              return "cor-mer";
          }else if(percent > 33 && percent <= 66){
              return "cor-or";
          }else{
             return "cor-gr"; 
          }
       
      }
      
      /*
       * Author: ankit
       */
      $scope.showTestReport = function(evt){
          $('.activeCurrentTab').removeClass('active');
          $(evt.currentTarget).parent().addClass('active');
          $('#coveragereport').hide();
          $('#testcoveragereport').show();
          //$scope.showCoverage = false;
          //$scope.showTestCoverage = true;
      }
      
      /*
       * Author: ankit
       */
      $scope.showCoverageReport = function(evt){
          $('.activeCurrentTab').removeClass('active');
          $(evt.currentTarget).parent().addClass('active');
          $('#coveragereport').show();
          $('#testcoveragereport').hide();
         // $scope.showCoverage = true;
          //$scope.showTestCoverage = false;
      }
     
   
});