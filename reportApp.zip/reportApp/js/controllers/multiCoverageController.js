var reportApp = angular.module('multiCoverageApp', ["ngRoute"]);
reportApp.controller('multiCoverageController', function($scope, $http,$window) {
    
    $scope.siteUrl = siteUrl;
    $scope.class_id = class_id;
    $scope.counter = 0;
if(class_id == '' ){
     $('.overallloader').hide();
    return false;
}
var coverageUrl = siteUrl+"/report/json/getmultipleCoverageReport/"+class_id;
      $http({
            method: "post",
            url: coverageUrl,
            headers: {
                'Content-Type': 'application/json'
            }
        }).success(function(data) {
            $scope.showCoverage = true;
            $('.overallloader').hide();
            $scope.coverageData = data;
            $scope.userId=[];
            $scope.childName=[];
            $scope.logintime  =[];
            $scope.className = [];
            $scope.boardName = [];
            $scope.classId = [];
            $.each(data,function(key,value){
                class_id = value.classId;
                $scope.userId.push({userId:value.coverage[0].userId});
                $scope.childName.push({childName:value.coverage[0].childName});
                $scope.logintime.push({logintime:value.coverage[0].lastlogin});
                $scope.boardName.push({boardName:value.board});
                $scope.className.push({className:value.class});
                $scope.classId.push({classId:value.classId});
//                $scope.coverageData[key].testCoverageReport = value.testCoverageReport; //true or false value
                if(value.testCoverageReport){
                        $http({
                       method: "post",
                       url: siteUrl+"/report/json/getmultipleCoverageTestReport/"+value.coverage[0].userId+"/"+class_id,
                       headers: {
                           'Content-Type': 'application/json'
                       }
                   }).success(function(data){
                       $scope.testPackage = true;
                       $scope.coverageData[key].testreport = data;
                   })
                    
                }
                
            })
             setTimeout(function() { 
                 $('.multiCoverageLoader').hide();
              $scope.onCoverageReady();
         }, 1000);
        });

      $scope.showTestReport = function(evt,index){
		    $('.activeCurrentTab').removeClass('active');
                    $(evt.currentTarget).parent().addClass('active');
                    $('#testcoveragereport'+index).show();
                    $('#coveragereport'+index).hide();
      }
      
      /*
       * Author: ankit
       */
      $scope.showCoverageReport = function(evt, index){
		  $('.activeCurrentTab').removeClass('active');
                  $(evt.currentTarget).parent().addClass('active');
                  $('#testcoveragereport'+index).hide();
                  $('#coveragereport'+index).show();
      }
     $scope.onCoverageReady = function(){
    
         $scope.createPieChart();
          $(".owl-carousel").owlCarousel({
          autoPlay: false, //Set AutoPlay to 3 seconds
          navigation : true,
          pagination : false, 
          items : 5,
          itemsDesktop : [1199,5],
          itemsDesktopSmall : [979,4]
          });
             // show hide test report //
             
             $('.showPackageTest').each(function(){
                 $(this).show();
                 $('#coveragereport'+$(this).attr('id').split('testcoveragereport')[1]).hide();
             });
             $('.activeCurrentTab').each(function(i){
                 $('.activeCurrentTab').removeClass('active');
                 $(this).addClass('active');
             })
     } 
     
     
      $scope.createPieChart = function(){
          $('.chart').each(function(){
              $(this).easyPieChart({barColor:'#67bde9'});
          });
     
      }
      
      $scope.showSubjectReport = function(subjectId,userId,classId){
         // report/index/coverage-report#/subjectreport/636/11112/11786/
          location.href = siteUrl+"/report/index/coverage-report#/subjectreport/"+userId+"/"+classId+'/'+subjectId;
      }
      
      //cloned from above for test package
      $scope.showSubjectTestReport = function(subjectId, userId, classId){
          location.href = siteUrl+"/report/index/coverage-report#/subjecttestreport/"+userId+"/"+classId+'/'+subjectId;
      }
});