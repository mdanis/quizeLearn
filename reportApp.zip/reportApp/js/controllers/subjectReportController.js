reportApp.controller('subjectReportController', function($scope, $http, service,appConst,$rootScope) {
    $('.showSubjectByClass').hide();
    $scope.siteUrl = appConst.siteUrl;
    $scope.subjects = [];
    $scope.chapters = [];
    $scope.chapterDetails = '';
    $scope.subjectsLoaded = false;
    service.showLoader('default');
      var url4 = appConst.siteUrl+"/report/json/breadcrumb/"+appConst.userId+"/"+appConst.classId+'/'+appConst.subjectId;
      service.getBreadscumData(url4);
    $scope.$on("updateCurrentPageData", function(event, data) {
       
        if(data.error == "true")return;
        //console.log("data after :: ",data)
        $scope.subjects = data.data;
         $scope.userType = data.userType;
         $scope.user = data.user;
         
         $scope.isTest = data.isTest;
         $scope.isLearn = data.isLearn;
         $scope.isPractice = data.isPractice;
         
        //service.hideLoader("default");
      
        if(!$scope.$$phase) {
           $scope.$apply();
        }

       setTimeout(function() { 
            service.hideLoader("default");
           $scope.onpageReady();
     }, 100);
    });

      $scope.onSubjectChange = function(id,name){
           service.showLoader();
          appConst.subjectId =  id;
          $scope.selectedSubjectName = name;
          $scope.chapterDetails = '';
          var successCallback = function(data){
               service.hideLoader("default");
              if(data && data.length > 0){
               $scope.chapters = data;
                if(!$scope.$$phase) {
                  $scope.$apply();
                 }
                 
                   setTimeout(function() {
                       $("#chapter_"+data[0].id).attr("checked","checked");                        
                   },100);   
                 $scope.onChapterSelect(data[0].id,data[0].chaptername);
              } else{
                  $scope.chapters = [];
              }
          }
          var errorCallback = function(){
              console.log("error in getting data")
          }
          var params = {
              "url":  $scope.siteUrl+"/report/json/get-chapter-wise-report/"+appConst.userId+'/'+id,
               "successCallback":successCallback,
               "errorCallback" : errorCallback
          }
          
          if($scope.isTest && !$scope.isLearn)
              params.url = $scope.siteUrl+"/report/json/get-chapter-wise-test-report/"+appConst.userId+'/'+id;
          service.getServiceData(params);
          //alert(id)
      }
      
       $scope.combineData = function(data){
         
         var data2 = {};
           angular.forEach(data, function(item,key) {
               if(key != "test"){
                 
               
               data2[key] = [];
             //  console.log("item : ",item);
               var subdata = _.groupBy(item, function(i){ return i.service});
             //  console.log("subdata : ",subdata);
             
               angular.forEach(subdata, function(sd,key2) {
                   var obj = {"service":key2 }
                 
                     var totalTime = 0;
               obj.totalSittings = 0;
               var count = 0;
                   angular.forEach(sd, function(item) {
                   var timeStr = item.time;
                   var time = 0;
                  var  timeArray = timeStr.split(":");
                   time = (parseInt(timeArray[0])*60*60*1000) +parseInt(timeArray[1]*60*1000)+parseInt(timeArray[2]*1000); 
                   totalTime += time;
                   obj.totalSittings += parseInt(item.sitting);
                   if(count == sd.length-1){
                       
                        var hrs = Math.floor(totalTime / (1000*60*60));
                        var min = Math.floor(totalTime % (1000*60*60) / (1000*60)).toFixed(0);
                        var sec = Math.floor(((totalTime % (1000*60*60)) % (1000*60)) / 1000);
                       
                        
                        if(hrs.toString().length == 1){
                           hrs = "0"+hrs.toString();
                        }
                         if(min.toString().length == 1){
                           min = "0"+min.toString();
                        }
                         if(sec.toString().length == 1){
                           sec = "0"+sec.toString();
                        }
                       obj.totalTime = hrs +':'+ min +':'+ sec;
                      
                      
                   }
                   count++;
               });
               data2[key].push(obj)
               //console.log("obj ::::",obj)
                });
           }
           });  
           
           
         //console.log("data2 ::::",data2)
        return data2;


       }
       $scope.testTime = function(time){
            var  timeArray = time.split(":");
                      var timeStr = '';
                       angular.forEach(timeArray,function(t,i){
                            if(t.toString().length == 1){
                           t = "0"+t.toString();
                           timeStr += t;
                           if(i != timeArray.length - 1 ){
                             timeStr += ":";
                           }
                        }else{
                         timeStr += t;   
                         if(i != timeArray.length - 1 ){
                             timeStr += ":";
                           }
                        }
                       }) 
                     return timeStr;
       };
       $scope.showDetail = function(id,target){
          var imgTag =  $(target).find("img");
          if($(imgTag).hasClass("report_closed")){
              $(id).show();
              $(imgTag).removeClass("report_closed").addClass("report_open");
          }else{
               $(id).hide();
              $(imgTag).removeClass("report_open").addClass("report_closed");
          }
           
       }
      $scope.onChapterSelect = function(id,name){
           service.showLoader();
          appConst.chapterId =  id;
          $scope.selectedChapterName = name;
          var successCallback = function(data){
          $scope.overView = $scope.combineData(data);
         //    console.log(" $scope.overView :: ", $scope.overView)
               $scope.chapterDetails = data;
               
                if(!$scope.$$phase) {
                  $scope.$apply();
                 }
                 
                 if($scope.isLearn)
                 $scope.tabclick('Learn');
             else
                 $scope.tabclick('Test');
             
                  service.hideLoader("default");
                  
        
          }
          var errorCallback = function(){
              console.log("error in getting data")
          }
          var params = {
              "url":  $scope.siteUrl+"/report/json/get-service-report/"+appConst.userId+'/'+id,
               "successCallback":successCallback,
               "errorCallback" : errorCallback
          }
          service.getServiceData(params);
          //alert(id)
      }
      
     $scope.onpageReady = function(){
         var id = appConst.subjectId;
         if(!appConst.subjectId){
             id = $scope.subjects[0].id;
         }
         $scope.subjectsLoaded = true;
         $('.showSubjectByClass').hide();
         $('#showSubjectById_'+id).show();
        $("#subject_"+id).attr("checked","checked");
        var subName =  $("#subject_"+id).attr("data");
        $scope.onSubjectChange(id,subName);
     }
     $scope.showAllSubject = function(evt){
         if($(evt.currentTarget).attr('name') == 'show'){
         $(evt.currentTarget).attr('name','hide');
         $(evt.currentTarget).text('Hide');
         $('.showSubjectByClass').show();
     }
     else{
         $(evt.currentTarget).text('View All Subject');
          $(evt.currentTarget).attr('name','show');
             var id = appConst.subjectId;
             if(!appConst.subjectId){
             id = $scope.subjects[0].id;
         }
           $('.showSubjectByClass').hide();
           $('#showSubjectById_'+id).show();
     }
     }
     $scope.showFeedback = function(subject_id){      
        //$("#overlay").show();
        /*var id = appConst.subjectId;
         if(!appConst.subjectId){
             id = $scope.subjects[0].id;
         }*/
         var id = subject_id
      $http({
                method: "post",
                url: appConst.siteUrl+'/report/index/view-feedback-list/'+appConst.userId+'/'+id+'/test',
                headers: {
                    'Content-Type': 'application/json'
                }
            }).success(function(data) {
               $('#reminder_pop1').show();
                $('#viewcomment').html(data);
                $('#viewcomment').show();
                    $(".close_button").click(function() {
                               $("#overlay").hide();
                             $('#viewcomment').hide();
                            });
                $('#exampleModalfeedback').modal('show');                
            }).error(function() {
              


            });
                            
    }
 
     $scope.showFeedbackForm = function(subject_id) {
        //$("#overlay").show();
        //$('#answer-popIn').show();
        $('#subjectId').val(subject_id);
        $('#Latestfeedback').modal('show');
        //$('#errorMessage').html('');
        //$('#coverageFeedback').val('');
        
    }
    
      $scope.hideFeedbackForm = function() {
        $("#overlay").hide();
        $('#answer-popIn').hide();
        
        
    }
    
     $scope.feedbackPopup = function() {
        var hidFeedCId = $('#hidFeedCId').val();
        $('#errorMessage').html('');
        var subjectId = $('#subjectId').val();
        var coverageFeedback = $('#coverageFeedback').val();
        if (coverageFeedback == '') {
            $('#errorMessage').html('Please write feedback');
        } else {
            //var subjectId = appConst.subjectId; 
            var data =  {hidstudent_id: appConst.userId,feedback_type: 'test',hidsubject_id: subjectId, feedbackCoverage: coverageFeedback, feedback: 'coverage', hidFeedCId: hidFeedCId, type: $scope.user, selectDate: '', subjectId: subjectId, getCoverage: 0};
                 
     var dataParam =  $.param(data);
                
      $http({
                method: "post",
                url: appConst.siteUrl+'/report/json/add-feedback',
              //  data: {hidstudent_id: appConst.userId, feedbackCoverage: coverageFeedback, feedback: 'coverage', hidFeedCId: hidFeedCId, type: $scope.user, selectDate: '', subjectId: subjectId, getCoverage: 0},
                  data :dataParam, 
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                    
                }
            }).success(function(data) {
                   if (data.output == 'success') {
                       //$('#errorMessage').html('<p style="color:green">Send succussesful</p>');
                         
                            alert('feedback posted successfully');
                            window.location.reload();
                        } else {
                            $('#errorMessage').html('<p style="color:red">You are not mentor of selected subject</p>');
                        }


            }).error(function() {
              


            });
            
        }
    }
    
     $scope.tabclick = function(index,elem){
          $(".activeLpt").removeClass("active");
          $(elem).attr("id","current");
            if (index == 'Learn') {
//                $scope.showLearn = true;
//                $scope.showPractice = false;
//                $scope.showTest = false;
           $(elem.currentTarget).parent().addClass('active');
           $('.service-coverage .tab-pane').hide();
           $('.service-coverage .tab-pane').removeClass('active');
           $('#tab1').addClass('active');
           $('#tab1').show();
            } else if (index == 'Practice') {
//               $scope.showLearn = false;
//                $scope.showPractice = true;
//                $scope.showTest = false;
           $(elem.currentTarget).parent().addClass('active');
           $('.service-coverage .tab-pane').hide();
           $('.service-coverage .tab-pane').removeClass('active');
           $('#tab2').show();
           $('#tab2').addClass('active');
            }
            else if (index == 'Test') {
//             $scope.showLearn = false;
//                $scope.showPractice = false;
//                $scope.showTest = true;
          $(elem.currentTarget).parent().addClass('active');
          $('.service-coverage .tab-pane').hide();
          $('.service-coverage .tab-pane').removeClass('active');
          $('#tab3').show();
          $('#tab3').addClass('active');
            }
     }
   
});
