reportApp.controller('mainController', function($scope,appConst,service) {
    
     service.showLoader('default');
     appConst.siteUrl = siteUrl;
     //appConst.rackId =classId;
  
     var params = location.hash.split("#/")[1]
     appConst.userId =  params.split("/")[1];
     appConst.rackId =  params.split("/")[2];
     if(location.hash == ''){
     location.hash = "coverage/"+ appConst.userId+"/"+appConst.rackId;
     }    // alert(appConst.siteUrl)
    
    
   /*  setTimeout(function() {
     if(location.hash == ""){
      location.hash = "/coverage"
     }
     }, 500);
            
            
     */
        
	});
