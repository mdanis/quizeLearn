var checkBreadcum=0;
reportApp.controller('breadscumController', function($scope, $http, service,appConst,$rootScope) {
    $scope.siteUrl = appConst.siteUrl;
    $scope.$on("updateBreadscum", function(event, data) {
        $scope.breadscumdetail = data.bredcrumbs;
        $scope.classDetail = data.bredcrumbs[0].class
        if(!$scope.$$phase) {
           $scope.$apply();
        }
    });
    
    $scope.getSubject = function(classList){
        $('#classListId').trigger('click');
        location.hash = "/coverage/"+appConst.userId+"/"+classList.rack_id;
    }
   $scope.addClass = function(last){
       if(last)
           return 'active';
   }
});