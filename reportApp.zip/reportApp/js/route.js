reportApp.config(function($routeProvider) {
            $routeProvider
                   
                    .when('/coverage/:userId/:classId', {
                            templateUrl : siteUrl+'/reportApp/templates/coverageTemplate.html',
                            controller  : 'coverageController'
                    })
                     .when('/subjectreport/:userId/:classId/:subjectId/', {
                            templateUrl : siteUrl+'/reportApp/templates/subjectReportTemplate.html',
                            controller  : 'subjectReportController'
                    })
                     .when('/subjecttestreport/:userId/:classId/:subjectId/', {
                            templateUrl : siteUrl+'/reportApp/templates/subjectReportTemplate.html',
                            controller  : 'subjectReportController'
                    })


	});
        

       

reportApp.run(function($http,$rootScope,appConst,service,$route) {
    
    $rootScope.$on('$locationChangeStart', function($event, newUrl, oldUrl){
        
      
    
  });
 
  $rootScope.$on('$routeChangeSuccess', function($event,current) {
      
    
      if(!current)return;
      
    
      
     
     var type =  current.originalPath.split("/")[1];
   
   /*  if(type == "chapterDetails"){
         return;
     }*/
     var parameters = current.params; 
     appConst.classId = parameters.classId;
     appConst.userId =  parameters.userId;
      appConst.subjectId =  parameters.subjectId;
     var url = "";
   
       switch(type){
          
                case "coverage" :  var url1 = appConst.siteUrl+"/report/json/get-coverage-report/"+appConst.userId+"/"+appConst.classId;
                    var url2 = appConst.siteUrl+"/report/json/get-test-performance/"+appConst.userId+"/"+appConst.classId;
                    var url3 = appConst.siteUrl+"/report/json/get-schedule/"+appConst.userId;
                    var url4 = appConst.siteUrl+"/report/json/breadcrumb/"+appConst.userId+"/"+appConst.classId;
                    service.getBreadscumData(url4);
                    
                              $http({
                                method: "post",
                                url: url1,
                                headers: {
                                    'Content-Type': 'application/json'
                                }
                            }).success(function(data) {
                                
                                 if(data.type == 'login'){
                                    getPopupForms('login');
                                    return;
                                 }        
                                 data.testPackage = false;
                                 
                                 if(data.testCoverageReport){
                                        data.testPackage = true;
                                        $http({
                                                method: "post",
                                                url: appConst.siteUrl+"/report/json/get-test-coverage-report/"+appConst.userId+"/"+appConst.classId,
                                                headers: {
                                                    'Content-Type': 'application/json'
                                                }
                                            }).success(function(testdata) {
                                                data.testcoverage = testdata.coverage;
                                                $rootScope.$broadcast('updateCoverData', data);
                                            });
                                 }else{
                                    $rootScope.$broadcast('updateCoverData', data);
                                 }


                            });
                                 $http({
                                method: "post",
                                url: url2,
                                headers: {
                                    'Content-Type': 'application/json'
                                }
                            }).success(function(data) {      
                             $rootScope.$broadcast('updateTestData', data);


                            });
                                 $http({
                                method: "post",
                                url: url3,
                                headers: {
                                    'Content-Type': 'application/json'
                                }
                            }).success(function(data) {
                             $rootScope.$broadcast('updateScheduleData', data);


                            });
                             return;
                                  break;
                case "subjectreport" :url = appConst.siteUrl+"/report/json/get-subject-wise-report/"+appConst.userId+"/"+appConst.classId;
                                   var url4 = appConst.siteUrl+"/report/json/breadcrumb/"+appConst.userId+"/"+appConst.classId+'/'+appConst.subjectId;
                                   //service.getBreadscumData(url4);
                                   break;
                case "subjecttestreport" :url = appConst.siteUrl+"/report/json/get-subject-wise-test-report/"+appConst.userId+"/"+appConst.classId;
                                   var url4 = appConst.siteUrl+"/report/json/breadcrumb/"+appConst.userId+"/"+appConst.classId+'/'+appConst.subjectId;
                                   // alert(JSON.stringify(parameters))
                                  // service.getBreadscumData(url4);
                                   break;
                default :
                    
                         break;
                
            }
          
          
      
        $http({
            method: "post",
            url: url,
            headers: {
                'Content-Type': 'application/json'
            }
        }).success(function(data) {
             if(data.type == 'login'){
                getPopupForms('login');
                return;
             }        
     
         $rootScope.$broadcast('updateCurrentPageData', data);
      
    
           //current
        });
     
  });
});
//var mcqServices = angular.module('mcqServices', ['ngResource']).value('version', '0.1');


	
	
        
      
